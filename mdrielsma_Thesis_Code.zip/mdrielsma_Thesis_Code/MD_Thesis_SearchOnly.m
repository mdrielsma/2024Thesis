% ===================================================================
% --- Multi-UAV Search Only ---
% Created by: Zihao Wang
% Modified by M.Drielsma for 2024 undergraduate Thesis
% Updated 01/11/2024
% 
% Instructions:
% - Change the 'test' variable for the number of UAVs you would like to
% simulate the search for
% - You can modify the dimensions of the world using the world_x and
% world_y variables
% ===================================================================
clc; clear; close all;
animation_f         = false;
videoWrite_f        = false;
if videoWrite_f
    video_saver     = VideoWriter('simulation.avi');
    video_saver.FrameRate = 5;
    open(video_saver);
end

%% ======== Inputs ======== %%
% Number of UAVs
test = 5;

% Set up the simulation world
world_x = 2000;
world_y = 1600;

%% ======================== %%

offset = 200; % Either side of border
%                           shape         x    y     grid size
world               = World('rectangle', [world_x+2*offset,world_y+2*offset], 20);
% Set time duration of simulation
time = 1000; % (s)

%% Set up agents - Type 2 is multirotor
% UAV velocity
ve = 15;
% Define starting positions of agents - counter clockwise position starting
% from right (Think ASTC).

if test == 1

% --- 1 agent ---
agent_start_pos = [ offset, offset];         % Agent 1
angle = [45];


elseif test == 2

% --- 2 agents ---
agent_start_pos = [ world_x+offset, offset;    % Agent 1
                    offset, offset];         % Agent 2
angle = [135, 45];

elseif test == 3
% --- 3 agents ---
agent_start_pos = [ world_x+offset, offset;           % Agent 1
                    offset, world_y+offset;           % Agent 2
                    offset, offset];                % Agent 3
angle = [135, -45, 45];

elseif test == 4

% --- 4 agents ---
agent_start_pos = [ world_x+offset, offset;          % Agent 1
                    world_x+offset, world_y+offset;    % Agent 2
                    offset, world_y+offset;          % Agent 3
                    offset, offset];               % Agent 4
angle = [135, -135, -45, 45];

elseif test == 5
% --- 5 agents ---
agent_start_pos = [ world_x+offset,offset;  % Agent 1
                    world_x+offset, world_y+offset;    % Agent 2
                    offset, world_y+offset;          % Agent 3
                    offset, offset;                % Agent 4
                    world_x+offset,offset];          % Agent 5
angle = [135, -135, -45, 45, 135];

end
                                     
%                              typ x                     y                     z   ro pc yaw             ve  max_ve  min_ve max_yawrate
% Agents vector
if test == 1
agent1              = Aircraft(2, agent_start_pos(1,1),  agent_start_pos(1,2), 50, 0, 0, deg2rad(angle(1)),   ve, ve, 0, deg2rad(180));

agents = [agent1];

elseif test == 2
agent1              = Aircraft(2, agent_start_pos(1,1),  agent_start_pos(1,2), 50, 0, 0, deg2rad(angle(1)),   ve, ve, 0, deg2rad(180));
agent2              = Aircraft(2, agent_start_pos(2,1),  agent_start_pos(2,2), 50, 0, 0, deg2rad(angle(2)),  ve,  ve,  0, deg2rad(180));

agents = [agent1;agent2];

elseif test == 3
agent1              = Aircraft(2, agent_start_pos(1,1),  agent_start_pos(1,2), 50, 0, 0, deg2rad(angle(1)),   ve, ve, 0, deg2rad(180));
agent2              = Aircraft(2, agent_start_pos(2,1),  agent_start_pos(2,2), 50, 0, 0, deg2rad(angle(2)),  ve,  ve,  0, deg2rad(180));
agent3              = Aircraft(2, agent_start_pos(3,1),  agent_start_pos(3,2), 50, 0, 0, deg2rad(angle(3)), ve,  ve, 0,  deg2rad(180));

agents = [agent1;agent2;agent3];

elseif test == 4
agent1              = Aircraft(2, agent_start_pos(1,1),  agent_start_pos(1,2), 50, 0, 0, deg2rad(angle(1)),   ve, ve, 0, deg2rad(180));
agent2              = Aircraft(2, agent_start_pos(2,1),  agent_start_pos(2,2), 50, 0, 0, deg2rad(angle(2)),  ve,  ve,  0, deg2rad(180));
agent3              = Aircraft(2, agent_start_pos(3,1),  agent_start_pos(3,2), 50, 0, 0, deg2rad(angle(3)), ve,  ve, 0,  deg2rad(180));
agent4              = Aircraft(2, agent_start_pos(4,1),  agent_start_pos(4,2), 50, 0, 0, deg2rad(angle(4)), ve,  ve, 0,  deg2rad(180));

agents = [agent1;agent2;agent3;agent4];

elseif test == 5
agent1              = Aircraft(2, agent_start_pos(1,1),  agent_start_pos(1,2), 50, 0, 0, deg2rad(angle(1)),   ve, ve, 0, deg2rad(180));
agent2              = Aircraft(2, agent_start_pos(2,1),  agent_start_pos(2,2), 50, 0, 0, deg2rad(angle(2)),  ve,  ve,  0, deg2rad(180));
agent3              = Aircraft(2, agent_start_pos(3,1),  agent_start_pos(3,2), 50, 0, 0, deg2rad(angle(3)), ve,  ve, 0,  deg2rad(180));
agent4              = Aircraft(2, agent_start_pos(4,1),  agent_start_pos(4,2), 50, 0, 0, deg2rad(angle(4)), ve,  ve, 0,  deg2rad(180));
agent5              = Aircraft(2, agent_start_pos(5,1),  agent_start_pos(5,2), 50, 0, 0, deg2rad(angle(5)), ve,  ve, 0,  deg2rad(180));

agents = [agent1;agent2;agent3;agent4;agent5];
end

numAgents = size(agents,1);
% Choose search mode (0 = lawnmower, 1 = PRM)
searchMode = 0;
% For searchmode 1 (RPM) define number of nodes
numNodes = 10;
% initialise agents with initial probability and environment uncertainty
for i = 1:size(agents,1)
    agents(i)       = initProbability(agents(i), world);
    agents(i)       = initUncertainty(agents(i), world);
end
%% Set up targets
% initialise target
%                            fligt x    y     z   heading       vel snse  max_vel  yaw_rate
target1             = Target(true, 0, 0,  20, deg2rad(360*rand(1)), 10,  200,  10,      deg2rad(20));
% target1             = Target(true, 0, 0,  20, deg2rad(180), 10,  200,  10,      deg2rad(20));
target2             = Target(true, -100, -100,  20, deg2rad(360*rand(1)), 0,  10,  0,      deg2rad(20));
targets             = [target1];
% initialise targets with initial interests
for k = 1:size(targets,1)
    targets(k)      = initInterests(targets(k), world);
end
%% Generate searching paths for UAVs
% coverage_path_combined = search(gridx,gridy,uavs,numNodes,searchMode)
[coverage_path_combined_x,coverage_path_combined_y] = search(world_x,world_y,length(agents),agent_start_pos,numNodes,searchMode,offset);
%% plotting world
aircraft_scale      = 30;
multirotor_scale    = 80;
target_scale        = 90;
color_pallete       = ['c';'y';'k';'m'];
color_pallete_agent = ['b';'g';'r';'k';'m'];
plotWorld;
% plot3(coverage_path_combined_x,coverage_path_combined_y,zeros(1,length(coverage_path_combined_y)),'linewidth',5);
%%
% start simulation
t_init              = 0;
t                   = t_init; % seconds
timer = t;
dt                  = 1; % seconds
t_total             = time;
cumulation          = 1;
iterations          = ceil(t_total/dt)+1;
% expand matrices to speed up code
world               = expandArrays(world, iterations);
for i = 1:size(agents,1)
    agents(i)       = expandArrays(agents(i), world, iterations);
end
for k = 1:size(targets,1)
    targets(k)      = expandArrays(targets(k), world, iterations);
end
% skip initial condition before the loop starts
cumulation          = cumulation+1;
t                   = t+dt;
% --- Initialising --- %
% Initialise modes in search mode for all agents
mode = zeros(1,size(agents,1));
% Initialise serach counter for all agents
counter = 2*ones(1,size(agents,1));
% Initialise waypoint arrays for agents
waypoint_x = zeros(1,size(agents,1));
waypoint_y = zeros(1,size(agents,1));
% Initialise other agents coordinates
other_agents_coordinates = zeros(size(agents,1),2);
while t <= t_total
    % =============================================================================================
    % update target
    for k = 1:size(targets,1)
        % update interests
        targets(k)  = updateInterests(targets(k), agents, world, cumulation);
        
        % move target
        targets(k)  = moveTarget(targets(k), world, cumulation, dt);
    end % end target loop
    
    % update global interests
    world           = updateGlobalInterests(world, targets, cumulation);
    
    %% =============================================================================================
    % control agents
    
    for i = 1:size(agents,1)
        % update uncertainty map
        agents(i)   = updateUncertainty(agents(i), world, cumulation);
        
        
        % update probability map
        [agents(i),mode(1,i)]   = updateProbabilitySearch(agents(i), targets, world, cumulation,mode(1,i));
       
        % get another agents coordinates
        for k = 1:size(agents,1)
            other_agents_coordinates(k,:) = [agents(k).x(cumulation-1),agents(k).y(cumulation-1)];
        end
        
%% =============== Perform Search mode ==========================================================
if mode(1,i) == 0
        % Set first waypoint
        if cumulation == 2
            
            waypoint_x(1,i) = coverage_path_combined_x(1,i);
            waypoint_y(1,i) = coverage_path_combined_y(1,i);
  
        end
        % If waypoint is set to (0,0) then just send it to its
        % starting position. This is because lawnmower node lists 
        % are not all same size for each UAV - Not the cleanest way
        % of doing it but it works :))
%         if waypoint_x(1,i) == 0 && waypoint_y(1,i) == 0
        if coverage_path_combined_y(counter(i)-1,i) == 0

            agents(i).velocity(cumulation-1) = 0;

        end
        
        % Calculate distance between agent and current waypoint
        dist = sqrt( (agents(i).x(cumulation-1) - waypoint_x(1,i))^2 + (agents(i).y(cumulation-1) - waypoint_y(1,i))^2 );
        
        % Return agent back to its starting position if it has not found
        % any birds after completing search manoeuvre
        if counter(i) == size(coverage_path_combined_x,1)+1 && dist <= 100
            
%              t = time;
           waypoint_x(1,i) = agent_start_pos(i,1);
           waypoint_y(1,i) = agent_start_pos(i,2);

           % Bring UAV to a stop when it arrives back at start position
           if dist <= 50 % m
           
                % Set agent velocity to zero
                agents(i).velocity(cumulation-1) = 0;
           end
        else
            % If UAV is near current waypoint then set the new waypoint
            if dist <= 100 % m
    
                % Update waypoints
                waypoint_x(1,i) = coverage_path_combined_x(counter(i),i);
                waypoint_y(1,i) = coverage_path_combined_y(counter(i),i);
    
                % Increase counter for each UAV
                counter(i) = counter(i) + 1;
    
            end
        end
            
        % Move agent to search waypoint
        agents(i)   = moveAgentSearch(agents(i), cumulation, dt,waypoint_x(1,i),waypoint_y(1,i));
% ======================= Perform Chase Mode ==========================================================
% % Switch to chase mode once bird has been detected
else    
        % Set agent velocity to zero if target is detected
        agents(i).velocity(cumulation-1) = 10;

        % Move agent
 agents(i) = moveAgentChase(agents(i), world, cumulation, dt, other_agents_coordinates,numAgents);
        
end
    end % end agent loop
   
    % update global uncertainty
    world           = updateGlobalUncertainty(world, agents, cumulation);
    
    % update global probability
    world           = updateGlobalProbability(world, agents, cumulation);
    
    %% =============================================================================================
    
    % ++++++++++++++++++++ debug figure +++++++++++++++++++
    figure(h2);
%     subplot(1,2,1);
    for j = 1:size(agents,1)
        delete(agents(j).figure_handle_debug);
        switch agents(j).type
            case 1
                agents(j).figure_handle_debug = uav(agents(j).x(cumulation), agents(j).y(cumulation), agents(j).z(cumulation),...
                         'roll', rad2deg(agents(j).roll(cumulation)), 'pitch', rad2deg(agents(j).pitch(cumulation)),...
                         'yaw', rad2deg(agents(j).yaw(cumulation)), 'scale', aircraft_scale, 'color', color_pallete_agent(j),...
                         'wing', color_pallete_agent(j), 'linestyle', 'none');
            case 2
%                 agents(j).figure_handle_debug = plot3(agents(j).x(cumulation), agents(j).y(cumulation), agents(j).z(cumulation));
                agents(j).figure_handle_debug = quadrotor(agents(j).x(cumulation), agents(j).y(cumulation), agents(j).z(cumulation),...
                         'roll', rad2deg(agents(j).roll(cumulation)), 'pitch', rad2deg(agents(j).pitch(cumulation)),...
                         'yaw', rad2deg(agents(j).yaw(cumulation)), 'scale', multirotor_scale, 'body', color_pallete_agent(j),...
                         'boom', color_pallete_agent(j), 'prop', color_pallete_agent(j), 'linestyle', 'none');
            otherwise
                agents(j).figure_handle_debug = uav(agents(j).x(cumulation), agents(j).y(cumulation), agents(j).z(cumulation),...
                         'roll', rad2deg(agents(j).roll(cumulation)), 'pitch', rad2deg(agents(j).pitch(cumulation)),...
                         'yaw', rad2deg(agents(j).yaw(cumulation)), 'scale', aircraft_scale, 'color', color_pallete_agent(j),...
                         'wing', color_pallete_agent(j), 'linestyle', 'none');
        end
        
        % draw position setpoint
        delete(agents(j).figure_handle_waypoint);
        agents(j).figure_handle_waypoint = plot3(agents(j).x_setpoint(cumulation), agents(j).y_setpoint(cumulation), agents(j).z(cumulation), ...
                'o', 'markersize', 10, 'color', color_pallete_agent(j),'linewidth',3);
    end
    for m = 1:size(targets,1)
        delete(targets(m).figure_handle_debug);
        targets(m).figure_handle_debug = birds(targets(m).x(cumulation), targets(m).y(cumulation), targets(m).z(cumulation), ...
                    'body', color_pallete(m), 'yaw', rad2deg(targets(m).heading(cumulation)), 'scale', target_scale);
        delete(targets(m).figure_handle_waypoint);
%         targets(m).figure_handle_waypoint = plot3(targets(m).x_setpoint(cumulation), targets(m).y_setpoint(cumulation), targets(m).z(cumulation), ...
%                     '^', 'markersize', 10, 'color', color_pallete(m));
    end
    delete(debug_map_handle);
    debug_map_handle = surf(world.meshgrid_XX,world.meshgrid_YY,world.prob_global(:,:,cumulation-1), 'facealpha', 1, 'linestyle', '-');
%     debug_map_handle = surf(world.meshgrid_XX,world.meshgrid_YY,world.inter_global(:,:,cumulation-1), 'facealpha', 1, 'linestyle', '-');
%     debug_map_handle = surf(world.meshgrid_XX,world.meshgrid_YY,agents(2).cost, 'facealpha', 1, 'linestyle', '-');
    title(['Time = ',num2str(timer),'s'],'FontSize',30,'FontName','Arial','FontWeight','Bold');
    
%     subplot(1,2,2);
%     plot(cumulation, sum(sum(world.prob_global(:,:,cumulation-1)))/world.number_of_tiles,'--or','markersize',10,'linewidth',2);
%     hold on;
%     title('Normalised global probability vs Time');
%     xlabel('Time (s)'); ylabel('Global probability');
    pbaspect([1 1 1]);
    set(gcf, 'Position', [100 100 1200 800]);
    set(gca, 'FontSize', 12);
    
    % plot agent trails
    for i = 1:size(agents,1)
    plot3(agents(i).x(cumulation), agents(i).y(cumulation), 30, 'o','Color',color_pallete_agent(i),'linewidth',3); hold on;
    end
    
    for i = 1:size(targets,1)
    % plot target trails
    plot3(targets(i).x(cumulation), targets(i).y(cumulation), 30, 'o','Color',color_pallete(i),'linewidth',3); hold on;
    end
    
    % plot boundaries
    drawRectangleColor(world.world_centre, world.size_x, world.size_y,offset);
%     if videoWrite_f
%         current_frame = getframe(gcf);
%         writeVideo(video_saver, current_frame);
%     end
    % ******************** debug figure ********************
    
    % increment time step
    t               = t + dt;
    timer = t;
    cumulation      = cumulation + 1;
end % end simulation loop

