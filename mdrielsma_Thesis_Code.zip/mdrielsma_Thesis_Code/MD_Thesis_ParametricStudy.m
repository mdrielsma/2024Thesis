% ===================================================================
% --- Parametric Study --- %
% Created by: Zihao Wang
% Modified by M.Drielsma for 2024 undergraduate Thesis
% Updated 01/11/2024
% 
% Instructions:
% - Set crop area size using world_x and world_y
% - Set simulation time, default is 1 hr (3600s)
% - Set bird appearance rate (birds/hr)
% - Set number of UAV pairs
% ===================================================================
clc; clear; close all;
animation_f         = false;
videoWrite_f        = false;

if videoWrite_f
    video_saver = VideoWriter('simulation.avi');
    video_saver.FrameRate = 5;
    open(video_saver);
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%% Input Parameters %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Crop area size
world_x = 1200; % (m)
world_y = 800; % (m)

% Set time duration of simulation (s)
time = 3600; 

% Bird appearance Rate (birds/hr)
birdsPerHour = 6;

% Number of agent pairs
pairs = 2;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Target rate of spawn
spawnRate = birdsPerHour/60; % (targets per minute) % 0.1 means 6 birds/hr
spawnIncrement = 60/spawnRate;

offset = 200;
%                           shape         x    y     grid size
world               = World('rectangle', [world_x+2*offset,world_y+2*offset], 20);

%% Set up agents - Type 2 is multirotor

% UAV velocity
ve = 15;

% Define starting positions of agents - counter clockwise position starting
% from right (Think ASTC).

% --- 2 agents ---
agent_start_pos = [ world_x+offset, offset;    % Agent 1
                    offset, offset];         % Agent 2
angle = [135, 45]; 

%                              typ x                     y                     z   ro pc yaw             ve  max_ve  min_ve max_yawrate
agent1              = Aircraft(2, agent_start_pos(1,1),  agent_start_pos(1,2), 20, 0, 0, deg2rad(angle(1)),   ve, ve, 0, deg2rad(180));
agent2              = Aircraft(2, agent_start_pos(2,1),  agent_start_pos(2,2), 20, 0, 0, deg2rad(angle(2)),  ve,  ve,  0, deg2rad(180));

% Agents vector
agents = [agent1;agent2];
numAgents = size(agents,1);

% % ------------ Initialise Agent Charging ----------------
% BatteryMatrix = 100*ones(1,pairs);
% AgentPair = 1;                  % Counter which keeps track of what UAV pair is active
% ChargingIncrement = 0.2;        % Percentage increments for battery charging
% search_depletionIncrement = 0.04;       % Percentage increments for battery depletion
% formation_depletionIncrement = 0.4;
% execute_depletionIncrement = 0.4;
% 
% BatteryMin = 20;                % Minimum allowable battery percentage
% % -------------------------------------------------------

% ------------ Initialise Agent Charging ----------------
BatteryMatrix = 100*ones(1,pairs);
AgentPair = 1;                  % Counter which keeps track of what UAV pair is active
multiplier = 5;             % Battery multiplier to scale things down
ChargingIncrement = multiplier*0.028;        % Percentage increments for battery charging
search_depletionIncrement = multiplier*0.01;       % Percentage increments for battery depletion
formation_depletionIncrement = multiplier*0.05;
execute_depletionIncrement = multiplier*0.05;

BatteryMin = 20;                % Minimum allowable battery percentage
% -------------------------------------------------------

% Choose search mode (0 = lawnmower, 1 = PRM)
searchMode = 0;
% For searchmode 1 (RPM) define number of nodes
numNodes = 50;

% initialise agents with initial probability and environment uncertainty
for i = 1:size(agents,1)
    agents(i)       = initProbability(agents(i), world);
    agents(i)       = initUncertainty(agents(i), world);
end

%% Set up targets
% initialise target
%                            flight   x    y     z   heading       vel snse  max_vel  yaw_rate
vt = 40; % velocity of target (m/s)

% Target positions
% Generate grid of evenly space points across whole area separated by a
% distance of 2 x detection radius
targets_x = 10; % Number of x targets
targets_y = 10; % Number of y targets
target_pos_x = linspace(offset+100,world_x+100,targets_x);
target_pos_y = linspace(world_y+100,offset+100,targets_y);

% Target positions for parametric study
target_pos = [target_pos_x(randi(5)),target_pos_y(randi(10));
              target_pos_x(randi(5)),target_pos_y(randi(10));
              target_pos_x(randi(5)),target_pos_y(randi(10));
              target_pos_x(randi(5)),target_pos_y(randi(10));
              target_pos_x(randi(5)),target_pos_y(randi(10));
              target_pos_x(randi(5)),target_pos_y(randi(10));
              target_pos_x(randi(5)),target_pos_y(randi(10))];

% % Target positions for parametric study
% target_pos = [target_pos_x(3),target_pos_y(4);
%               target_pos_x(5),target_pos_y(7);
%               target_pos_x(7),target_pos_y(2);
%               target_pos_x(3),target_pos_y(7);
%               target_pos_x(7),target_pos_y(8);
%               target_pos_x(5),target_pos_y(3);
%               target_pos_x(4),target_pos_y(7)];

% target_pos = [700,600;
%               1000,400;
%               350,900;
%               400,650;
%               800 500;
%               700 400;
%               1200 800];

% border_buffer = 100;
% target_pos = [offset+border_buffer+(world_x-200)*rand(1),offset+border_buffer+(world_y-200)*rand(1);
%               offset+border_buffer+(world_x-200)*rand(1),offset+border_buffer+(world_y-200)*rand(1);
%               offset+border_buffer+(world_x-200)*rand(1),offset+border_buffer+(world_y-200)*rand(1);
%               offset+border_buffer+(world_x-200)*rand(1),offset+border_buffer+(world_y-200)*rand(1);
%               offset+border_buffer+(world_x-200)*rand(1),offset+border_buffer+(world_y-200)*rand(1);
%               offset+border_buffer+(world_x-200)*rand(1),offset+border_buffer+(world_y-200)*rand(1)];

% ============== Target Setup ============
% target1             = Target(true, 1100, 900,  20, deg2rad(360*rand(1)), 20,  200,  20,      deg2rad(20));
% target1             = Target(true, 2*offset+(world_x-2*offset)*rand(1), 2*offset+(world_y-2*offset)*rand(1),  20, deg2rad(360*rand(1)), vt,  200,  vt,      deg2rad(20));
    target1             = Target(true, target_pos(1,1),target_pos(1,2),  20, deg2rad(360*rand(1)), vt,  200,  vt,      deg2rad(20));
    target2             = Target(true, 1, 1,  20, deg2rad(360*rand(1)), vt,  200, vt,      deg2rad(20));
    target3             = Target(true, 1,1,  20, deg2rad(360*rand(1)), vt,  200,  vt,      deg2rad(20));
 
% target_pos = [0,0;
%               0,0;
%               0,0];
% ========================================
% target1             = Target(true, offset + world_x*rand(1), offset + world_y*rand(1),  20, deg2rad(360*rand(1)), 0,  200,  10,      deg2rad(20));
targets             = [target1;target2;target3];

% initialise targets with initial interests
for k = 1:size(targets,1)
    targets(k)      = initInterests(targets(k), world);
end

%% Generate searching paths for UAVs

% coverage_path_combined = search(gridx,gridy,uavs,numNodes,searchMode)
[coverage_path_combined_x,coverage_path_combined_y] = search(world_x,world_y,length(agents),agent_start_pos,numNodes,searchMode,offset);

%% plotting world
aircraft_scale      = 30;
multirotor_scale    = 80;
target_scale        = 90;
color_pallete       = ['c';'c';'c';'c'];
color_pallete_agent = ['b';'g';'r';'c';'m'];
plotWorld;
% plot3(coverage_path_combined_x,coverage_path_combined_y,zeros(1,length(coverage_path_combined_y)),'linewidth',5);

%%
% start simulation
t_init              = 0;
t                   = t_init; % seconds
dt                  = 1; % seconds
t_total             = time;
cumulation          = 1;
iterations          = ceil(t_total/dt)+1;

% expand matrices to speed up code
world               = expandArrays(world, iterations);
for i = 1:size(agents,1)
    agents(i)       = expandArrays(agents(i), world, iterations);
end
for k = 1:size(targets,1)
    targets(k)      = expandArrays(targets(k), world, iterations);
end

% skip initial condition before the loop starts
cumulation          = cumulation+1;
t                   = t+dt;

% --- Initialising --- %
% Initialise modes in search mode for all agents
agentMode = zeros(1,size(agents,1));
mode = zeros(1,size(agents,1));
chase = zeros(1,size(agents,1));
% Initialise search counter for all agents
counter = 2*ones(1,size(agents,1));
circ_counter = 0;
% Initialise waypoint arrays for agents
waypoint_x = zeros(1,size(agents,1));
waypoint_y = zeros(1,size(agents,1));
% Initialise other agents coordinates
other_agents_coordinates = zeros(size(agents,1),2);
foundCounter = 1;
detectionCounter = 0;
target_counter = 1;
target_reset_counter = 0;
nextPairCounter = 0;
active_targets = zeros(1,size(targets,1));
active_counter = 0;

% Create x and y arrays for area boundaries
boundaryIndices = 200;
boundary_x = zeros(boundaryIndices,4);
boundary_y = zeros(boundaryIndices,4);

% x boundaries
boundary_x(:,1) = offset*ones(boundaryIndices,1);                   % Left
boundary_x(:,2) = linspace(offset,world_x+offset,boundaryIndices)'; % Top
boundary_x(:,3) = (world_x+offset)*ones(boundaryIndices,1);         % Right
boundary_x(:,4) = linspace(offset,world_x+offset,boundaryIndices)'; % Bottom

% y boundaries
boundary_y(:,1) = linspace(offset,world_y+offset,boundaryIndices)'; % Left
boundary_y(:,2) = (world_y+offset)*ones(boundaryIndices,1);         % Top
boundary_y(:,3) = linspace(offset,world_y+offset,boundaryIndices)'; % Right
boundary_y(:,4) = offset*ones(boundaryIndices,1);                   % Bottom

next_bird = 1;
next_position = 2;
b = 2;

%% ================================= MAIN LOOP ====================================================
while t <= t_total
    % =============================================================================================
    % update target

    if t == next_bird*round(spawnIncrement)

        % Change target position
        targets(b).x(cumulation-1) = target_pos(next_position,1);
        targets(b).y(cumulation-1) = target_pos(next_position,2);

        next_bird = next_bird + 1;

        % increment next bird position
        if next_position == size(target_pos,1)
            next_position = 1;
        else
            next_position = next_position + 1;
        end

        % increment bird to appear
        if b == size(targets,1)

            b = 1;

        else
            b = b + 1;
        end

        fprintf('b = %d\n',b);
        fprintf('next_bird = %d\n',next_bird);
        fprintf('next_position = %d\n',next_position);
        fprintf('t = %d\n',t);

    end

%     if t == 1*spawnIncrement
% 
%         % Change target position
%         targets(2).x(cumulation-1) = target_pos(2,1);
%         targets(2).y(cumulation-1) = target_pos(2,2);
% 
%     elseif t == 2*spawnIncrement
% 
%         % Change target position
%         targets(3).x(cumulation-1) = target_pos(3,1);
%         targets(3).y(cumulation-1) = target_pos(3,2);
% 
%     elseif t == 3*spawnIncrement
%         % Change target position
%         targets(1).x(cumulation-1) = target_pos(4,1);
%         targets(1).y(cumulation-1) = target_pos(4,2);
% 
%     elseif t == 4*spawnIncrement
%         % Change target position
%         targets(2).x(cumulation-1) = target_pos(5,1);
%         targets(2).y(cumulation-1) = target_pos(5,2);
%      
%      elseif t == 5*spawnIncrement
%         % Change target position
%         targets(3).x(cumulation-1) = target_pos(6,1);
%         targets(3).y(cumulation-1) = target_pos(6,2);
% 
%     elseif t == 6*spawnIncrement
%         % Change target position
%         targets(1).x(cumulation-1) = target_pos(7,1);
%         targets(1).y(cumulation-1) = target_pos(7,2);
% 
%      elseif t == 7*spawnIncrement
%         % Change target position
%         targets(2).x(cumulation-1) = target_pos(1,1);
%         targets(2).y(cumulation-1) = target_pos(1,2);
% 
%      elseif t == 8*spawnIncrement
%         % Change target position
%         targets(3).x(cumulation-1) = target_pos(2,1);
%         targets(3).y(cumulation-1) = target_pos(2,2);
% 
%      elseif t == 9*spawnIncrement
%         % Change target position
%         targets(1).x(cumulation-1) = target_pos(3,1);
%         targets(1).y(cumulation-1) = target_pos(3,2);
% 
%      elseif t == 10*spawnIncrement
%         % Change target position
%         targets(2).x(cumulation-1) = target_pos(4,1);
%         targets(2).y(cumulation-1) = target_pos(4,2);
% 
%      elseif t == 11*spawnIncrement
%         % Change target position
%         targets(3).x(cumulation-1) = target_pos(5,1);
%         targets(3).y(cumulation-1) = target_pos(5,2);
%     end

    % --------------------------------------------------------------------
    %% Calculation of target vector
    % Obtain target initial position
    target_x = targets(target_counter).x(cumulation-1);
    target_y = targets(target_counter).y(cumulation-1);
    r_detection = agents(i).camera_range-50; % Make 50m less than UAV camera range
    
    % Determine closest boundary to target (see labelling)
    distTargetBoundary = zeros(1,4);
    
    distTargetBoundary(1,1) = targets(target_counter).x(cumulation-1) - offset;            % Left = 1
    distTargetBoundary(1,2) = world_y - targets(target_counter).y(cumulation-1) + offset;  % Top = 2
    distTargetBoundary(1,3) = world_x - targets(target_counter).x(cumulation-1) + offset;  % Right = 3
    distTargetBoundary(1,4) = targets(target_counter).y(cumulation-1) - offset;            % Bottom = 4
    
    % Closest boundary to target
    [~,i_closest] = min(distTargetBoundary);

     % If closest boundary is left or right then start circle points at 180
    % deg
    if i_closest == 1

        % Generate circle around the target
        [x_circle,y_circle] = circle(target_x,target_y,r_detection,pi);

    % Start at 270 deg
    elseif i_closest == 2

        [x_circle,y_circle] = circle(target_x,target_y,r_detection,pi/2);

    % Start at 180 deg
    elseif i_closest == 3

        [x_circle,y_circle] = circle(target_x,target_y,r_detection,pi);

    else % Start at 270 deg

        [x_circle,y_circle] = circle(target_x,target_y,r_detection,pi/2);

    end
    
    % Initialise closest boundary distances array
    closestBoundaryDist = zeros(1,boundaryIndices);
    
    % Find point on boundary closest to target
    for n = 1:boundaryIndices
    
        closestBoundaryDist(1,n) = sqrt( (target_x - boundary_x(n,i_closest) )^2 + (target_y - boundary_y(n,i_closest))^2 );
       
    end
        
    % Get index of closest boundary point
    [~,closestBoundary] = min(closestBoundaryDist);
    
    % Closest point on closest boundary
    closest_x = boundary_x(closestBoundary,i_closest);
    closest_y = boundary_y(closestBoundary,i_closest);
    
    % Plot circle and point P
%     plot3(x_circle,y_circle,ones(length(x_circle)),'r-','linewidth',3);
%     plot3(closest_x,closest_y,1,'ro','linewidth',5);
    
    % Get unit vector from target to closest edge point
    % This is the vector that we want the bird to go in
    target_vec = [closest_x-target_x,closest_y-target_y]./norm(closest_x-target_x,closest_y-target_y);
    % --------------------------------------------------------------------

    for k = 1:size(targets,1)

        % update interests
        targets(k)  = updateInterests(targets(k), agents, world, cumulation);
        
        % move target
        targets(k)  = moveTarget(targets(k), world, cumulation, dt);

        % Check if a target is active in the area
        if targets(k).x(cumulation) > offset

           active_targets(k) = 1;
        else
            active_targets(k) = 0;

        end

    end % end target loop

    % Count how many targets are active in the area
    active_targets_sum = sum(active_targets);

    if active_targets_sum > 1

        % Time how long there is more than one target active
        active_counter = active_counter + 1;
    else
        % Set time counter to zero if there is less than targets active
        active_counter = 0;
    end

    % Stop simulation if there are more than 1 target for longer than 100s
    if active_counter == 120

        t = time;

    end

%     disp(active_targets);
%     disp(active_counter);
    
    % update global interests
    world = updateGlobalInterests(world, targets, cumulation);
    
%% =============================================================================================
% control agents

%     disp(mode)

    % ------------ Agent Battery Levels ------------ %
    
    for k = 1:length(BatteryMatrix)
        
        % DECREASING CHARGE
        if k == AgentPair && BatteryMatrix(k) > 0

            % --- Search mode ---
            if mode(1,1) == 0 || mode(1,1) == 4

            % Reduce battery by increment
            BatteryMatrix(k) = BatteryMatrix(k) - search_depletionIncrement;

            % --- Formation mode ---
            elseif mode(1,1) == 1

                % Reduce battery by increment
                BatteryMatrix(k) = BatteryMatrix(k) - formation_depletionIncrement;

            % 
            elseif mode(1,1) == 2 || mode(1,1) == 3

                % Reduce battery by increment
                BatteryMatrix(k) = BatteryMatrix(k) - execute_depletionIncrement;

            end
        
        % INCREASING CHARGE    
        elseif k ~= AgentPair && BatteryMatrix(k) < 100

            % Reduce battery by increment
            BatteryMatrix(k) = BatteryMatrix(k) + ChargingIncrement;

        end

        battery_tracker(cumulation-1,k) = BatteryMatrix(k);

    end

%     disp(BatteryMatrix);
    % ---------------------------------- %

for i = 1:size(agents,1)

    % If at any point the agent's battery life is less than some percentage then send back
    % to starting position for charging
    if BatteryMatrix(AgentPair) < BatteryMin
       
       % mode 4 will send back to starting pos
       mode(1,:) = 4;
    
    end

    % update uncertainty map
    agents(i)   = updateUncertainty(agents(i), world, cumulation);
    
    if mode(1,i) == 0

        % update probability map
        [agents(i),mode(1,i)]   = updateProbabilitySearch(agents(i), targets, world, cumulation,mode(1,i));
    
    else % For modes 1 (hover) and 2 (execute)
        % update probability map
        [agents(i),mode(1,i)]   = updateProbabilityHover(agents(i), targets, world, cumulation,mode(1,i));

    end

        % disp(mode);

    % get another agents coordinates
    for k = 1:size(agents,1)

        other_agents_coordinates(k,:) = [agents(k).x(cumulation-1),agents(k).y(cumulation-1)];

    end
        
%% =============== Perform Search mode ==========================================================
if mode(1,i) == 0

        % Set first waypoint
        if cumulation == 2
            
            waypoint_x(1,i) = coverage_path_combined_x(1,i);
            waypoint_y(1,i) = coverage_path_combined_y(1,i);
  
        end
        
        % Calculate distance between agent and current waypoint
        dist(1,i) = sqrt( (agents(i).x(cumulation-1) - waypoint_x(1,i))^2 + (agents(i).y(cumulation-1) - waypoint_y(1,i))^2 );

        % Restart searching manoeuvre if agent has not found any targest
        if counter(i) == size(coverage_path_combined_x,1)+1 && dist(1,i) <= 100

           counter(1,i) = 1;

        else

            % If UAV is near current waypoint then set the new waypoint
            if dist(1,i) <= 100 % m
    
                % Update waypoints
                waypoint_x(1,i) = coverage_path_combined_x(counter(i),i);
                waypoint_y(1,i) = coverage_path_combined_y(counter(i),i);
    
                % Increase counter for each UAV
                counter(i) = counter(i) + 1;
    
            end

        end

        % If waypoint is set to (0,0) then just send it to its
        % starting position. This is because lawnmower node lists 
        % are not all same size for each UAV - Not the cleanest way
        % of doing it but it works :))
        if waypoint_x(1,i) == 0 && waypoint_y(1,i) == 0

            waypoint_x(1,i) = coverage_path_combined_x(1,i);
            waypoint_y(1,i) = coverage_path_combined_y(1,i);

        end
            
        % Move agent to search waypoint
        agents(i) = moveAgentSearch(agents(i), cumulation, dt,waypoint_x(1,i),waypoint_y(1,i));

% ======================= Bird Detected - Hover in place ==========================================================

elseif mode(1,i) == 1 % Transition to hover mode to await other agent to join

    % Determine point on circle that has 45 degree angle to target vector
    for k = 1:length(x_circle)

        % Vector from agent to target
        agent_vec = [target_x - x_circle(k), target_y - y_circle(k)]...
                    ./norm(target_x - x_circle(k), target_y -  y_circle(k));

        % Angle between agent vector and target deterrence vector
        theta = acosd(dot(target_vec,agent_vec)/(norm(target_vec)*norm(agent_vec)));

        % Suitable waypoints on the circle will have an angle theta between 
        % 45 to 50 degrees
        if theta > 20 && theta < 25

           % Increment counter
           circ_counter = circ_counter + 1;

           % Save index on circle
           circle_indices(1,circ_counter) = k;
           
           % Allocate suitable waypoints on circle
           circle_waypoint_x(1,circ_counter) = x_circle(k);
           circle_waypoint_y(1,circ_counter) = y_circle(k);

        end

    end

    % Only do this for the first UAV that finds the bird
    if foundCounter <= 1

        % Increment to 2 so that this if statement is not visited again
        foundCounter = foundCounter + 1;

        % Loop through suitable waypoints on circle
        for h = 1:length(circle_indices)
        
            % Calculate distances to possible circle waypoints
            % circ_dist(1,h) = sqrt( (agents(i).x(cumulation-1) - circle_waypoint_x(1,h))^2 + (agents(i).y(cumulation-1) - circle_waypoint_y(1,h))^2 );
            circ_dist(1,h) = sqrt( (agents(i).x(cumulation-1) - x_circle(1,circle_indices(h)))^2 + (agents(i).y(cumulation-1) - y_circle(1,circle_indices(h)))^2 );


        end

        % Determine minimum distance to circle
        [~,minCircDist] = min(circ_dist);

    end

    % Get index of agent that detects the target first (will be either 1
    % or 2) - Only do this once when target is detected
    if detectionCounter < 1

        detecting_agent = find(mode == 1);
    
        % Increment counter so this only happens once
        detectionCounter = detectionCounter + 1;

        % Call over other agent
        mode(1,size(agents,1)+1-detecting_agent) = 1;

    end

    % Set waypoint to that point on the circle - agent that detects
%     waypoint_x(1,detecting_agent) = circle_waypoint_x(minCircDist);
%     waypoint_y(1,detecting_agent) = circle_waypoint_y(minCircDist);
    waypoint_x(1,detecting_agent) = x_circle(circle_indices(minCircDist));
    waypoint_y(1,detecting_agent) = y_circle(circle_indices(minCircDist));

    % Set waypoint to that point on the circle - agent that did not detect
%     waypoint_x(1,size(agents,1)+1-detecting_agent) = circle_waypoint_x(abs(circ_counter + 1 - minCircDist));
%     waypoint_y(1,size(agents,1)+1-detecting_agent) = circle_waypoint_y(abs(circ_counter + 1 - minCircDist));
    
    waypoint_x(1,size(agents,1)+1-detecting_agent) = x_circle(length(x_circle)-circle_indices(minCircDist)+1);
    waypoint_y(1,size(agents,1)+1-detecting_agent) = y_circle(length(y_circle)-circle_indices(minCircDist)+1);
    
    % distance between agent and waypoint
    dist(1,i) = sqrt( (agents(i).x(cumulation-1) - waypoint_x(1,i))^2 + (agents(i).y(cumulation-1) - waypoint_y(1,i))^2 );

    % Slow down agent on approach so that it begins to hover
    if dist(1,i) < 30

        % Set velocity to zero
        agents(i).velocity(cumulation-1) = 0;

        % Switch agent mode to 2 -> chase mode
        mode(1,i) = 2;
   
    end

    % Move agent to waypoint
    agents(i) = moveAgentSearch(agents(i), cumulation, dt,waypoint_x(1,i),waypoint_y(1,i));

% ============================ Chase Bird now that other UAV has arrived =========================
elseif mode(1,i) == 2 % Execute cooperative bird chasing

    % Set target reset counter to zero so that targets get sent back to
    % zero when found
    target_reset_counter = 0;

    % First agents waits (hovers) for other agent to be in position
    if sum(mode) < 2*size(agents,1)
       
       % Set velocity to zero
       agents(i).velocity(cumulation-1) = 0;
    
    else
        % Set velocity to 10 when executing
        agents(i).velocity(cumulation-1) = 5;

        % Set waypoints for agents
        % If nearest boundary to target is on right or left boundary
        if i_closest == 1 || i_closest == 3
           
            % Agent 1
            waypoint_x(1,detecting_agent) = closest_x;
            waypoint_y(1,detecting_agent) = circle_waypoint_y(minCircDist);

            % Agent 2
            waypoint_x(1,size(agents,1)+1-detecting_agent) = closest_x;
            waypoint_y(1,size(agents,1)+1-detecting_agent) = circle_waypoint_y(circ_counter + 1 - minCircDist);


        else % If nearest boundary to target is top or bottom

            % Agent 1
            waypoint_x(1,detecting_agent) = circle_waypoint_x(minCircDist);
            waypoint_y(1,detecting_agent) = closest_y;

            % Agent 2
            waypoint_x(1,size(agents,1)+1-detecting_agent) = circle_waypoint_x(circ_counter + 1 - minCircDist);
            waypoint_y(1,size(agents,1)+1-detecting_agent) = closest_y;

        end


        % distance between agent and waypoint
        dist(1,i) = sqrt( (agents(i).x(cumulation-1) - waypoint_x(1,i))^2 + (agents(i).y(cumulation-1) - waypoint_y(1,i))^2 );

        % Transition to mode 3 when near boundary - bird has been deterred
        % successfully
        if dist(1,i) < 50

            % Agent goes into mode 3 - From here either restarts search or
            % goes back to starting position
            mode(1,:) = 3;

            if target_reset_counter == 0

            % Change target position
            targets(target_counter).x(cumulation) = -200;
            targets(target_counter).y(cumulation) = -200;
%             targets(target_counter).velocity(cumulation-1) = vt;
%             targets(target_counter).max_velocity(cumulation-1) = vt;
            
                if target_counter == 3

                    target_counter = 1;

                else
                    % Increment target counter -> UAVs will move onto next target 
                    target_counter = target_counter + 1;

                end
    
            % Increment target reset counter so that this only happens once
            target_reset_counter = target_reset_counter + 1;

            end
       
        end

    end

    % Execute coordinated chase towards boundary
    agents(i) = moveAgentExecute(agents(i), cumulation, dt,waypoint_x(1,i),waypoint_y(1,i));

% ============================ Deterrence completed - return to search mode =========================
elseif mode(1,i) == 3 % Mode = 3

    % Resume searching at last search point
    waypoint_x(1,i) = coverage_path_combined_x(counter(i)-1,i);
    waypoint_y(1,i) = coverage_path_combined_y(counter(i)-1,i);

    % Move agent to search waypoint
    agents(i) = moveAgentSearch(agents(i), cumulation, dt,waypoint_x(1,i),waypoint_y(1,i));

     % distance between agent and waypoint
    dist(1,i) = sqrt( (agents(i).x(cumulation-1) - waypoint_x(1,i))^2 + (agents(i).y(cumulation-1) - waypoint_y(1,i))^2 );

    if dist(1,i) < 100

        % Switch agent mode to 0 -> search mode
        mode(1,i) = 0;

        % Reset foundCounter and detectionCounter for when revisiting mode 2
        foundCounter = 0;
        detectionCounter = 0;
        circ_counter = 0;
   
    end
% ============================ Battery depleted - go charge =========================
else % mode = 4 - Battery below threshold - send back for charging
    
    % Set waypoint to starting position
    waypoint_x(1,i) = agent_start_pos(i,1);
    waypoint_y(1,i) = agent_start_pos(i,2);

     % distance between agent and waypoint
    dist(1,i) = sqrt( (agents(i).x(cumulation-1) - waypoint_x(1,i))^2 + (agents(i).y(cumulation-1) - waypoint_y(1,i))^2 );

    if dist(1,i) < 30

       % Set velocity to zero upon approach
       agents(i).velocity(cumulation-1) = 0;

       % Set velocity to zero upon approach
       agents(i).yaw(cumulation-1) = angle(i);

       if dist(1,1) < 30 && dist(1,2) < 30

           % Use counter so that this is only visited once
           if nextPairCounter == 0

               % Assign next agent pair
               if AgentPair == length(BatteryMatrix)
    
                  % If last pair then next pair is the first pair
                  nextPair = 1;
    
               else
                   nextPair = AgentPair + 1;
    
               end

               nextPairCounter = nextPairCounter + 1;

           end

           % Check if the next pair has more than 80% battery
%            if BatteryMatrix(1,nextPair) > 80
           if BatteryMatrix(1,nextPair) >= 100

           % Send next pair of agents into search mode
           mode(1,:) = 0;

           % Reset nextPairCounter to zero
           nextPairCounter = 0;
    
               % Check Agent Pair counter
               if AgentPair == length(BatteryMatrix)
        
                   % Set back to first pair of UAVs
                   AgentPair = 1;
        
               else
                   % Increment Agent Pair counter - next UAVs in use
                   AgentPair = AgentPair + 1;
        
               end
           else
               t = time;
           end

       end

    else

    % Move agent back to starting pos
    agents(i) = moveAgentSearch(agents(i), cumulation, dt,waypoint_x(1,i),waypoint_y(1,i));

    end
    
end

% =====================================================================================================

end % end agent loop

    % update global uncertainty
    world           = updateGlobalUncertainty(world, agents, cumulation);
    
    % update global probability
    world           = updateGlobalProbability(world, agents, cumulation);
    
    % =============================================================================================
    
%     ++++++++++++++++++++ debug figure +++++++++++++++++++
    figure(h2);
%     subplot(1,2,1);
    for j = 1:size(agents,1)
        delete(agents(j).figure_handle_debug);
        switch agents(j).type
            case 1
                agents(j).figure_handle_debug = uav(agents(j).x(cumulation), agents(j).y(cumulation), agents(j).z(cumulation),...
                         'roll', rad2deg(agents(j).roll(cumulation)), 'pitch', rad2deg(agents(j).pitch(cumulation)),...
                         'yaw', rad2deg(agents(j).yaw(cumulation)), 'scale', aircraft_scale, 'color', color_pallete_agent(j),...
                         'wing', color_pallete_agent(j), 'linestyle', 'none');
            case 2
%                 agents(j).figure_handle_debug = plot3(agents(j).x(cumulation), agents(j).y(cumulation), agents(j).z(cumulation));
                agents(j).figure_handle_debug = quadrotor(agents(j).x(cumulation), agents(j).y(cumulation), agents(j).z(cumulation),...
                         'roll', rad2deg(agents(j).roll(cumulation)), 'pitch', rad2deg(agents(j).pitch(cumulation)),...
                         'yaw', rad2deg(agents(j).yaw(cumulation)), 'scale', multirotor_scale, 'body', color_pallete_agent(AgentPair),...
                         'boom', color_pallete_agent(AgentPair), 'prop', color_pallete_agent(AgentPair), 'linestyle', 'none');
            otherwise
                agents(j).figure_handle_debug = uav(agents(j).x(cumulation), agents(j).y(cumulation), agents(j).z(cumulation),...
                         'roll', rad2deg(agents(j).roll(cumulation)), 'pitch', rad2deg(agents(j).pitch(cumulation)),...
                         'yaw', rad2deg(agents(j).yaw(cumulation)), 'scale', aircraft_scale, 'color', color_pallete_agent(j),...
                         'wing', color_pallete_agent(j), 'linestyle', 'none');
        end
        
        % draw position setpoint
        delete(agents(j).figure_handle_waypoint);
        agents(j).figure_handle_waypoint = plot3(agents(j).x_setpoint(cumulation), agents(j).y_setpoint(cumulation), agents(j).z(cumulation), ...
                'o', 'markersize', 10, 'color', color_pallete_agent(AgentPair),'linewidth',3);
    end
    for m = 1:size(targets,1)


        delete(targets(m).figure_handle_debug);
        targets(m).figure_handle_debug = birds(targets(m).x(cumulation), targets(m).y(cumulation), targets(m).z(cumulation), ...
                    'body', color_pallete(m), 'yaw', rad2deg(targets(m).heading(cumulation)), 'scale', target_scale);
        delete(targets(m).figure_handle_waypoint);
%         targets(m).figure_handle_waypoint = plot3(targets(m).x_setpoint(cumulation), targets(m).y_setpoint(cumulation), targets(m).z(cumulation), ...
%                     '^', 'markersize', 10, 'color', color_pallete(m));

    end
   delete(debug_map_handle);
    debug_map_handle = surf(world.meshgrid_XX,world.meshgrid_YY,world.prob_global(:,:,cumulation-1), 'facealpha', 1, 'linestyle', '-');
%   debug_map_handle = surf(world.meshgrid_XX,world.meshgrid_YY,world.inter_global(:,:,cumulation-1), 'facealpha', 1, 'linestyle', '-');
%   debug_map_handle = surf(world.meshgrid_XX,world.meshgrid_YY,agents(2).cost, 'facealpha', 1, 'linestyle', '-');
   title(['Time = ',num2str(t),'s'],'FontSize',30,'FontName','Arial','FontWeight','Bold');
   %colorbar;
    
%     subplot(1,2,2);
%     plot(cumulation, sum(sum(world.prob_global(:,:,cumulation-1)))/world.number_of_tiles,'--or','markersize',10,'linewidth',2);
%     hold on;
%     title('Normalised global probability vs Time');
%     xlabel('Time (s)'); ylabel('Global probability');
    pbaspect([1 1 1]);
    set(gcf, 'Position', [100 100 1200 800]);
    set(gca, 'FontSize', 12);
    
%     % plot agent trails
%     for i = 1:size(agents,1)
%     plot3(agents(i).x(cumulation), agents(i).y(cumulation), 30, 'o','Color',color_pallete_agent(i),'linewidth',3); hold on;
%     end
%     
%     % plot target trails
%     for i = 1:size(targets,1)
%     % plot target trails
%     plot3(targets(i).x(cumulation), targets(i).y(cumulation), 30, 'o','Color',color_pallete(i),'linewidth',3); hold on;
%     end
    
    % plot boundaries
    drawRectangleColor(world.world_centre, world.size_x, world.size_y,offset);

    if videoWrite_f
        current_frame = getframe(gcf);
        writeVideo(video_saver, current_frame);
    end

    %% ******************** debug figure ******************** %%
    
    % increment time step
    t               = t + dt;
    cumulation      = cumulation + 1;

%     disp(t);
% disp(active_counter);

end % end simulation loop

figure
time_array = 1:1:length(battery_tracker);

for uavs = 1:pairs
plot(time_array,battery_tracker(:,uavs),'linewidth',2)
hold on
end

grid on
xlabel('Time (s)');
ylabel('Battery Percentage');
legend('UAV pair 1','UAV pair 2','UAV pair 3','UAV pair 4');
% title('A = 1200 x 800 m, r = 0.3')

% if videoWrite_f
%     close(video_saver);
% end
%animation;