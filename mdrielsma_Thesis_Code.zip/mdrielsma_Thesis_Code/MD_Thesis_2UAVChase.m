% ===================================================================
% --- Deterrence with 2 UAVs and 1 bird --- %
% Created by: Zihao Wang
% Modified by M.Drielsma for 2024 undergraduate Thesis
% Updated 01/11/2024
% 
% Instructions:
% - Set world dimensions using world_x and world_y
% - Set bird location between using x_bird and y_bird bewteen 1 and 20
% - Set simulation time
% ===================================================================
clc; clear; close all;
animation_f         = false;
videoWrite_f        = false;

if videoWrite_f
    video_saver = VideoWriter('simulation.avi');
    video_saver.FrameRate = 5;
    open(video_saver);
end

%% ======== Inputs ======== %%
% Crop area dimensions
world_x = 1400;
world_y = 1000;

% Bird position - Choose x and y between 1 and 20
x_bird = 5;
y_bird = 10;

% Set time duration of simulation
time = 1000; % (s)
%% ======================== %%

offset = 200;

% Target positions
% Generate grid of evenly space points across whole area separated by a
% distance of 2 x detection radius
targets_x = 20; % Number of x targets
targets_y = 20; % Number of y targets
target_pos_x = linspace(offset+100,world_x+100,targets_x);
target_pos_y = linspace(world_y+100,offset+100,targets_y);

% Array for storing deter time for each test
deter_time = zeros(length(target_pos_x),length(target_pos_y));

vt = 20; % velocity of target (m/s)

%% ========================== Loop through different trials =================================
for x = x_bird % 1:length(target_pos_x)
    for y = y_bird  % 1:length(target_pos_y)

    close all
%                           shape         x    y     grid size
world               = World('rectangle', [world_x+2*offset,world_y+2*offset], 20);

%% Set up agents - Type 2 is multirotor

% UAV velocity
ve = 15;

% Define starting positions of agents - counter clockwise position starting
% from right (Think ASTC).
% --- 2 agents ---
agent_start_pos = [ world_x+offset, offset;    % Agent 1
                    offset, offset];         % Agent 2
angle = [135, 45];
                                    
%                              typ x                     y                     z   ro pc yaw             ve  max_ve  min_ve max_yawrate
agent1              = Aircraft(2, agent_start_pos(1,1),  agent_start_pos(1,2), 20, 0, 0, deg2rad(angle(1)),   ve, ve, 0, deg2rad(180));
agent2              = Aircraft(2, agent_start_pos(2,1),  agent_start_pos(2,2), 20, 0, 0, deg2rad(angle(2)),  ve,  ve,  0, deg2rad(180));

% Agents vector
agents = [agent1;agent2];
numAgents = size(agents,1);

% Choose search mode (0 = lawnmower, 1 = PRM)
searchMode = 0;

% For searchmode 1 (RPM) define number of nodes
numNodes = 50;

% initialise agents with initial probability and environment uncertainty
for i = 1:size(agents,1)
    agents(i)       = initProbability(agents(i), world);
    agents(i)       = initUncertainty(agents(i), world);
end

% Set up targets
% initialise target
%                            flight x    y     z   heading       vel snse  max_vel  yaw_rate
% ============== Target Setup ============
% target1             = Target(true, target_pos_x(x), target_pos_y(y),  20, deg2rad(360*rand(1)), vt,  200,  vt,      deg2rad(180));
target1             = Target(true, target_pos_x(x), target_pos_y(y),  20, deg2rad(180), vt,  200,  vt,      deg2rad(180));

targets             = [target1];

% initialise targets with initial interests
for k = 1:size(targets,1)
    targets(k)      = initInterests(targets(k), world);
end

%% Generate searching paths for UAVs

% coverage_path_combined = search(gridx,gridy,uavs,numNodes,searchMode)
[coverage_path_combined_x,coverage_path_combined_y] = search(world_x,world_y,length(agents),agent_start_pos,numNodes,searchMode,offset);

%% plotting world
aircraft_scale      = 30;
multirotor_scale    = 80;
target_scale        = 90;
color_pallete       = ['c';'y';'k';'m'];
color_pallete_agent = ['b';'g';'r';'c';'m'];
plotWorld;
% plot3(coverage_path_combined_x,coverage_path_combined_y,zeros(1,length(coverage_path_combined_y)),'linewidth',5);

%%
% start simulation
t_init              = 0;
t                   = t_init; % seconds
timer = t_init;
dt                  = 1; % seconds
t_total             = time;
cumulation          = 1;
iterations          = ceil(t_total/dt)+1;

% expand matrices to speed up code
world               = expandArrays(world, iterations);
for i = 1:size(agents,1)
    agents(i)       = expandArrays(agents(i), world, iterations);
end
for k = 1:size(targets,1)
    targets(k)      = expandArrays(targets(k), world, iterations);
end

% skip initial condition before the loop starts
cumulation          = cumulation+1;
t                   = t+dt;

% --- Initialising --- %
% Initialise modes in search mode for all agents
agentMode = zeros(1,size(agents,1));
mode = zeros(1,size(agents,1));
chase = zeros(1,size(agents,1));
% Initialise search counter for all agents
counter = 2*ones(1,size(agents,1));
circ_counter = 0;
% Initialise waypoint arrays for agents
waypoint_x = zeros(1,size(agents,1));
waypoint_y = zeros(1,size(agents,1));
% Initialise other agents coordinates
other_agents_coordinates = zeros(size(agents,1),2);
foundCounter = 1;
detectionCounter = 1;
target_reset_counter = 0;
target_counter = 1;

% Create x and y arrays for area boundaries
boundaryIndices = 200;
boundary_x = zeros(boundaryIndices,4);
boundary_y = zeros(boundaryIndices,4);

% x boundaries
boundary_x(:,1) = offset*ones(boundaryIndices,1);                   % Left
boundary_x(:,2) = linspace(offset,world_x+offset,boundaryIndices)'; % Top
boundary_x(:,3) = (world_x+offset)*ones(boundaryIndices,1);         % Right
boundary_x(:,4) = linspace(offset,world_x+offset,boundaryIndices)'; % Bottom

% y boundaries
boundary_y(:,1) = linspace(offset,world_y+offset,boundaryIndices)'; % Left
boundary_y(:,2) = (world_y+offset)*ones(boundaryIndices,1);         % Top
boundary_y(:,3) = linspace(offset,world_y+offset,boundaryIndices)'; % Right
boundary_y(:,4) = offset*ones(boundaryIndices,1);                   % Bottom

%% ================================= MAIN LOOP ====================================================
while t <= t_total
    % =============================================================================================
    % update target

     % --------------------------------------------------------------------
    %% Calculation of target vector
    % Obtain target initial position
    target_x = targets(target_counter).x(cumulation-1);
    target_y = targets(target_counter).y(cumulation-1);
    r_detection = agents(i).camera_range-50; % Make 50m less than UAV camera range
    
    % Determine closest boundary to target (see labelling)
    distTargetBoundary = zeros(1,4);
    
    distTargetBoundary(1,1) = targets(target_counter).x(cumulation-1) - offset;            % Left = 1
    distTargetBoundary(1,2) = world_y - targets(target_counter).y(cumulation-1) + offset;  % Top = 2
    distTargetBoundary(1,3) = world_x - targets(target_counter).x(cumulation-1) + offset;  % Right = 3
    distTargetBoundary(1,4) = targets(target_counter).y(cumulation-1) - offset;            % Bottom = 4
    
    % Closest boundary to target
    [~,i_closest] = min(distTargetBoundary);

    % If closest boundary is left or right then start circle points at 180
    % deg
    if i_closest == 1

        % Generate circle around the target
        [x_circle,y_circle] = circle(target_x,target_y,r_detection,pi);

    % Start at 270 degtr
    elseif i_closest == 2

        [x_circle,y_circle] = circle(target_x,target_y,r_detection,3*pi/2);

    % Start at 180 deg
    elseif i_closest == 3

        [x_circle,y_circle] = circle(target_x,target_y,r_detection,pi);

    else % Start at 270 deg

        [x_circle,y_circle] = circle(target_x,target_y,r_detection,3*pi/2);

    end
    
    % Initialise closest boundary distances array
    closestBoundaryDist = zeros(1,boundaryIndices);
    
    % Find point on boundary closest to target
    for n = 1:boundaryIndices
    
        closestBoundaryDist(1,n) = sqrt( (target_x - boundary_x(n,i_closest) )^2 + (target_y - boundary_y(n,i_closest))^2 );
       
    end
    
    % Get index of closest boundary point
    [~,closestBoundary] = min(closestBoundaryDist);
    
    % Closest point on closest boundary
    closest_x = boundary_x(closestBoundary,i_closest);
    closest_y = boundary_y(closestBoundary,i_closest);
    
    % Get unit vector from target to closest edge point
    % This is the vector that we want the bird to go in
    target_vec = [closest_x-target_x,closest_y-target_y]./norm(closest_x-target_x,closest_y-target_y);
    % --------------------------------------------------------------------

    for k = 1:size(targets,1)

        % update interests
        targets(k)  = updateInterests(targets(k), agents, world, cumulation);
        
        % move target
        targets(k)  = moveTarget(targets(k), world, cumulation, dt);

    end % end target loop
    
    % update global interests
    world = updateGlobalInterests(world, targets, cumulation);
    
%% =============================================================================================
% control agents

for i = 1:size(agents,1)

    % update uncertainty map
    agents(i)   = updateUncertainty(agents(i), world, cumulation);
    
    if mode(1,i) == 0

        % update probability map
        [agents(i),mode(1,i)]   = updateProbabilitySearch(agents(i), targets, world, cumulation,mode(1,i));
    
    else % For modes 1 (hover) and 2 (execute)
        % update probability map
        [agents(i),mode(1,i)]   = updateProbabilityHover(agents(i), targets, world, cumulation,mode(1,i));

    end

        % disp(mode);

    % get another agents coordinates
    for k = 1:size(agents,1)

        other_agents_coordinates(k,:) = [agents(k).x(cumulation-1),agents(k).y(cumulation-1)];

    end
        
%% =============== Perform Search mode ==========================================================
if mode(1,i) == 0

        % Set first waypoint
        if cumulation == 2
            
            waypoint_x(1,i) = coverage_path_combined_x(1,i);
            waypoint_y(1,i) = coverage_path_combined_y(1,i);
  
        end
        
        % Calculate distance between agent and current waypoint
        dist(1,i) = sqrt( (agents(i).x(cumulation-1) - waypoint_x(1,i))^2 + (agents(i).y(cumulation-1) - waypoint_y(1,i))^2 );

        % Restart searching manoeuvre if agent has not found any targest
        if counter(i) == size(coverage_path_combined_x,1)+1 && dist(1,i) <= 100

           counter(1,i) = 1;

        else

            % If UAV is near current waypoint then set the new waypoint
            if dist(1,i) <= 100 % m
    
                % Update waypoints
                waypoint_x(1,i) = coverage_path_combined_x(counter(i),i);
                waypoint_y(1,i) = coverage_path_combined_y(counter(i),i);
    
                % Increase counter for each UAV
                counter(i) = counter(i) + 1;
    
            end

        end

        % If waypoint is set to (0,0) then just send it to its
        % starting position. This is because lawnmower node lists 
        % are not all same size for each UAV - Not the cleanest way
        % of doing it but it works :))
        if waypoint_x(1,i) == 0 && waypoint_y(1,i) == 0

            waypoint_x(1,i) = coverage_path_combined_x(1,i);
            waypoint_y(1,i) = coverage_path_combined_y(1,i);

        end
            
        % Move agent to search waypoint
        agents(i) = moveAgentSearch(agents(i), cumulation, dt,waypoint_x(1,i),waypoint_y(1,i));

% ======================= Bird Detected - Hover in place ==========================================================

elseif mode(1,i) == 1 % Transition to hover mode to await other agent to join

    % Determine point on circle that has 45 degree angle to target vector
    for k = 1:length(x_circle)

        % Vector from agent to target
        agent_vec = [target_x - x_circle(k), target_y - y_circle(k)]...
                    ./norm(target_x - x_circle(k), target_y -  y_circle(k));

        % Angle between agent vector and target deterrence vector
        theta = acosd(dot(target_vec,agent_vec)/(norm(target_vec)*norm(agent_vec)));

        % Suitable waypoints on the circle will have an angle theta between 
        % 45 to 50 degrees
        if theta > 20 && theta < 25

           % Increment counter
           circ_counter = circ_counter + 1;

           % Save index on circle
           circle_indices(1,circ_counter) = k;
           
           % Allocate suitable waypoints on circle
           circle_waypoint_x(1,circ_counter) = x_circle(k);
           circle_waypoint_y(1,circ_counter) = y_circle(k);

        end

    end

    % Only do this for the first UAV that finds the bird
    if foundCounter <= 1

        plot3(x_circle,y_circle,10*ones(200),'r','linewidth',2);

        % Increment to 2 so that this if statement is not visited again
        foundCounter = foundCounter + 1;

        % Loop through suitable waypoints on circle
        for h = 1:length(circle_indices)
        
            % Calculate distances to possible circle waypoints
            % circ_dist(1,h) = sqrt( (agents(i).x(cumulation-1) - circle_waypoint_x(1,h))^2 + (agents(i).y(cumulation-1) - circle_waypoint_y(1,h))^2 );
            circ_dist(1,h) = sqrt( (agents(i).x(cumulation-1) - x_circle(1,circle_indices(h)))^2 + (agents(i).y(cumulation-1) - y_circle(1,circle_indices(h)))^2 );


        end

        % Determine minimum distance to circle
        [~,minCircDist] = min(circ_dist);

    end

    % Get index of agent that detects the target first (will be either 1
    % or 2) - Only do this once when target is detected
    if detectionCounter < 2

        [~,detecting_agent] = max(mode);
    
        % Increment counter so this only happens once
        detectionCounter = detectionCounter + 1;

    end

    % Call over other agent
    mode(1,size(agents,1)+1-detecting_agent) = 1;

    % Set waypoint to that point on the circle - agent that detects
    waypoint_x(1,detecting_agent) = x_circle(circle_indices(minCircDist));
    waypoint_y(1,detecting_agent) = y_circle(circle_indices(minCircDist));

    waypoint_x(1,size(agents,1)+1-detecting_agent) = x_circle(length(x_circle)-circle_indices(minCircDist)+1);
    waypoint_y(1,size(agents,1)+1-detecting_agent) = y_circle(length(y_circle)-circle_indices(minCircDist)+1);
    
    % distance between agent and waypoint
    dist(1,i) = sqrt( (agents(i).x(cumulation-1) - waypoint_x(1,i))^2 + (agents(i).y(cumulation-1) - waypoint_y(1,i))^2 );

    % Slow down agent on approach so that it begins to hover
    if dist(1,i) < 30

        % Set velocity to zero
        agents(i).velocity(cumulation-1) = 0;

        % Switch agent mode to 2 -> chase mode
        mode(1,i) = 2;

        if dist(1,1) < 30

        plot3(x_circle,y_circle,10*ones(200),'r','linewidth',2);

        end
   
    end

    % Move agent to waypoint
    agents(i) = moveAgentSearch(agents(i), cumulation, dt,waypoint_x(1,i),waypoint_y(1,i));

% ============================ Chase Bird now that other UAV has arrived =========================
else % mode(1,i) == 2 % Execute cooperative bird chasing

    % First agents waits (hovers) for other agent to be in position
    if sum(mode) < 2*size(agents,1)
       
       % Set velocity to zero
       agents(i).velocity(cumulation-1) = 0;
    
    else
        % Set velocity to 10 when executing
        agents(i).velocity(cumulation-1) = 3;

        % Set waypoints for agents
        % If nearest boundary to target is on right or left boundary
        if i_closest == 1 || i_closest == 3
           
            % Agent 1
            waypoint_x(1,detecting_agent) = closest_x;
            waypoint_y(1,detecting_agent) = circle_waypoint_y(minCircDist);

            % Agent 2
            waypoint_x(1,size(agents,1)+1-detecting_agent) = closest_x;
            waypoint_y(1,size(agents,1)+1-detecting_agent) = circle_waypoint_y(circ_counter + 1 - minCircDist);


        else % If nearest boundary to target is top or bottom

            % Agent 1
            waypoint_x(1,detecting_agent) = circle_waypoint_x(minCircDist);
            waypoint_y(1,detecting_agent) = closest_y;

            % Agent 2
            waypoint_x(1,size(agents,1)+1-detecting_agent) = circle_waypoint_x(circ_counter + 1 - minCircDist);
            waypoint_y(1,size(agents,1)+1-detecting_agent) = closest_y;

        end


        % distance between agent and waypoint
        dist(1,i) = sqrt( (agents(i).x(cumulation-1) - waypoint_x(1,i))^2 + (agents(i).y(cumulation-1) - waypoint_y(1,i))^2 );

        % Transition to mode 3 when near boundary - bird has been deterred
        % successfully
        if dist(1,1) < 20 && dist(1,2) < 20

            agents(i).velocity(cumulation-1) = 0;

            % Only visit this once per trial
            if target_reset_counter == 0

                % Store deterrence time once target has been deterred
                deter_time(y,x) = t;

                % Stop Simulation
                t = time;

               % Increment target reset counter so that this only happens once
                target_reset_counter = target_reset_counter + 1;


            end
            
       
        end

    end

    % Execute coordinated chase towards boundary
    agents(i) = moveAgentExecute(agents(i), cumulation, dt,waypoint_x(1,i),waypoint_y(1,i));

end

% =====================================================================================================

end % end agent loop

    % update global uncertainty
    world           = updateGlobalUncertainty(world, agents, cumulation);
    
    % update global probability
    world           = updateGlobalProbability(world, agents, cumulation);
    
    %% =============================================================================================
    
    % ++++++++++++++++++++ debug figure +++++++++++++++++++
    figure(h2);
%     subplot(1,2,1);
    for j = 1:size(agents,1)
        delete(agents(j).figure_handle_debug);
        switch agents(j).type
            case 1
                agents(j).figure_handle_debug = uav(agents(j).x(cumulation), agents(j).y(cumulation), agents(j).z(cumulation),...
                         'roll', rad2deg(agents(j).roll(cumulation)), 'pitch', rad2deg(agents(j).pitch(cumulation)),...
                         'yaw', rad2deg(agents(j).yaw(cumulation)), 'scale', aircraft_scale, 'color', color_pallete_agent(j),...
                         'wing', color_pallete_agent(j), 'linestyle', 'none');
            case 2
%                 agents(j).figure_handle_debug = plot3(agents(j).x(cumulation), agents(j).y(cumulation), agents(j).z(cumulation));
                agents(j).figure_handle_debug = quadrotor(agents(j).x(cumulation), agents(j).y(cumulation), agents(j).z(cumulation),...
                         'roll', rad2deg(agents(j).roll(cumulation)), 'pitch', rad2deg(agents(j).pitch(cumulation)),...
                         'yaw', rad2deg(agents(j).yaw(cumulation)), 'scale', multirotor_scale, 'body', color_pallete_agent(j),...
                         'boom', color_pallete_agent(j), 'prop', color_pallete_agent(j), 'linestyle', 'none');
            otherwise
                agents(j).figure_handle_debug = uav(agents(j).x(cumulation), agents(j).y(cumulation), agents(j).z(cumulation),...
                         'roll', rad2deg(agents(j).roll(cumulation)), 'pitch', rad2deg(agents(j).pitch(cumulation)),...
                         'yaw', rad2deg(agents(j).yaw(cumulation)), 'scale', aircraft_scale, 'color', color_pallete_agent(j),...
                         'wing', color_pallete_agent(j), 'linestyle', 'none');
        end
        
        % draw position setpoint
        delete(agents(j).figure_handle_waypoint);
        agents(j).figure_handle_waypoint = plot3(agents(j).x_setpoint(cumulation), agents(j).y_setpoint(cumulation), agents(j).z(cumulation), ...
                'o', 'markersize', 10, 'color', color_pallete_agent(j),'linewidth',3);
    end
    for m = 1:size(targets,1)
        delete(targets(m).figure_handle_debug);
        targets(m).figure_handle_debug = birds(targets(m).x(cumulation), targets(m).y(cumulation), targets(m).z(cumulation), ...
                    'body', color_pallete(m), 'yaw', rad2deg(targets(m).heading(cumulation)), 'scale', target_scale);
        delete(targets(m).figure_handle_waypoint);
%         targets(m).figure_handle_waypoint = plot3(targets(m).x_setpoint(cumulation), targets(m).y_setpoint(cumulation), targets(m).z(cumulation), ...
%                     '^', 'markersize', 10, 'color', color_pallete(m));
    end
   delete(debug_map_handle);
    debug_map_handle = surf(world.meshgrid_XX,world.meshgrid_YY,world.prob_global(:,:,cumulation-1), 'facealpha', 1, 'linestyle', '-');
%   debug_map_handle = surf(world.meshgrid_XX,world.meshgrid_YY,world.inter_global(:,:,cumulation-1), 'facealpha', 1, 'linestyle', '-');
%   debug_map_handle = surf(world.meshgrid_XX,world.meshgrid_YY,agents(2).cost, 'facealpha', 1, 'linestyle', '-');
   title(['Time = ',num2str(timer),'s'],'FontSize',30,'FontName','Arial','FontWeight','Bold');
    
%     subplot(1,2,2);
%     plot(cumulation, sum(sum(world.prob_global(:,:,cumulation-1)))/world.number_of_tiles,'--or','markersize',10,'linewidth',2);
%     hold on;
%     title('Normalised global probability vs Time');
%     xlabel('Time (s)'); ylabel('Global probability');
    pbaspect([1 1 1]);
    set(gcf, 'Position', [100 100 1200 800]);
    set(gca, 'FontSize', 12);
    
    % plot agent trails
    for i = 1:size(agents,1)
    plot3(agents(i).x(cumulation), agents(i).y(cumulation), 19, 'o','Color',color_pallete_agent(i),'linewidth',3); hold on;
    end
    
    % plot target trails
    for i = 1:size(targets,1)
    % plot target trails
    plot3(targets(i).x(cumulation), targets(i).y(cumulation), 19, 'o','Color',color_pallete(i),'linewidth',3); hold on;
    end
    
    % plot boundaries
    drawRectangleColor(world.world_centre, world.size_x, world.size_y,offset);

%     if videoWrite_f
%         current_frame = getframe(gcf);
%         writeVideo(video_saver, current_frame);
%     end

    % ******************** debug figure ********************
    
    % increment time step
    t               = t + dt;
    timer = t;
    cumulation      = cumulation + 1;

end % end simulation loop


    end
end
