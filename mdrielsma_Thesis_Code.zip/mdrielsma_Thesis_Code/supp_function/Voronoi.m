clear;
clc;
close all

%%%%%%%%%%%%%%%%%%%% INPUT VARIABLES %%%%%%%%%%%%%%%%%%%%

gridx = 1500;           % x length of grid space
gridy = 1000;           % y length of grid space
uavs = 3;               % Number of UAVs
targets = 0;            % Number of targets
searchMode = 0;         % Search mode (0 = lawnmower, 1 = proabilistic)
numNodes = 50;          % Number of nodes per section (for searchMode = 1);
detectionRadius = 50;  % UAV detection radius (m)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% UAV starting positions
%start_positions = [gridx/2, gridy/2];
start_positions = [0, 0];

% Targets:
for i = 1:targets
    
    target_pos(i,:) = [rand(1,1)*gridx, rand(1,1)*gridy];

end

% Initialise final coverage
totalCoverageMatrix = zeros(gridy,gridx); % Will be the total coverage of all UAVs

%% --- Voronoi and PRM generation --- %%

% Centre of grid space
centre = [gridx/2, gridy/2];

% Radius of voronoi points circle
r = gridy/4;

% Initialise x and y coords of voronoi points
voronoi_x = zeros(1,uavs);
voronoi_y = zeros(1,uavs);

for i = 1:uavs
    
    % Angular separation
    theta = 2*pi/uavs;
    
    % Calculate voronoi x and y coordinates
    voronoi_x(i) = gridx/2 + r*cos((i-1)*theta);
    voronoi_y(i) = gridy/2 + r*sin((i-1)*theta);
    
end

% Distances from node to voronoi points
voronoi_dist = zeros(1,uavs);

figure(1)
plot(gridx,gridy)
hold on
axis([-200 gridx+200 -200 gridy+200]);
colors = ['r', 'b', 'g', 'k','m','c'];
grid on
grid minor

if uavs > 2
voronoi(voronoi_x,voronoi_y);
end

% Plot target positions
for i = 1:targets
    
    plot(target_pos(i,1),target_pos(i,2),'mo','linewidth',8);
    
end

%% Plot area boundaries
plot([0 0],[0,gridy],'k-','linewidth',2)            % Left
plot([0 gridx],[gridy gridy],'k-','linewidth',2);   % Top
plot([gridx gridx],[gridy 0],'k-','linewidth',2);   % Right
plot([0 gridx],[0 0],'k-','linewidth',2);           % Bottom

%% Lawnmower approach
if searchMode == 0

% Generate grid of evenly space points across whole area separated by a
% distance of 2 x detection radius
nodes_x = linspace(detectionRadius,gridx-detectionRadius,floor(0.5*gridx/detectionRadius));
nodes_y = linspace(detectionRadius,gridy-detectionRadius,floor(0.5*gridy/detectionRadius)+1);

for i = 1:uavs
   
    % Initialise node counter
    nodeCounter = 0;
     % Initialise nodes list and node counter
    nodes = [];

    % Loop through all nodes
    for m = 1:length(nodes_x)
        for n = 1:length(nodes_y)

        % Define node
        node = [nodes_x(m),nodes_y(n)];

            % Loop through different voronoi points
            for j = 1:length(voronoi_x)

                % Calculate distances between the node and chosen voronoi point
                voronoi_dist(j) = sqrt( (node(1)-voronoi_x(j))^2 + (node(2)-voronoi_y(j))^2 );

            end
        
            % If the indice of the minimum distance to a node is equal to the
            % uav number then it is in the correct sector
            [~,minDist] = min(voronoi_dist);
            if minDist == i

               % Add node to nodes list
               nodes = [nodes;node];

                % Increment node counter
                nodeCounter = nodeCounter + 1;

            end


          end
    end

    % Plot the PRM nodes
    plot(nodes(:,1), nodes(:,2), 'o', 'Color', colors(i));
    hold on
    
    % Perform CCPP within the sector
    coverage_path = ccpp(nodes,start_positions);
    
    % Perform coverage analysis
    totalCoverageMatrix = get_coverage(gridx,gridy,nodeCounter,nodes,detectionRadius,totalCoverageMatrix);

    % Plot the coverage path for UAV
    plot(coverage_path(:,1), coverage_path(:,2), '-', 'Color', colors(i), 'LineWidth', 2);
    
end

%% Probabilistic Approach
else


    for i = 1:uavs
        
        % Initialise node counter
        nodeCounter = 1;
        % Initialise nodes list and node counter
        nodes = [];

        while nodeCounter <= numNodes

            % Generate a random node
            node = [rand(1,1)*gridx, rand(1,1)*gridy];

            % Loop through different voronoi points
            for j = 1:length(voronoi_x)

                % Calculate distances between the node and chosen voronoi point
                voronoi_dist(j) = sqrt( (node(1)-voronoi_x(j))^2 + (node(2)-voronoi_y(j))^2 );

            end

            % If the indice of the minimum distance to a node is equal to the
            % uav number then it is in the correct sector
            [~,minDist] = min(voronoi_dist);
            if minDist == i

               % Add node to nodes list
               nodes = [nodes;node];

                % Increment node counter
                nodeCounter = nodeCounter + 1;

            end

        end

        % Plot the PRM nodes
        plot(nodes(:,1), nodes(:,2), 'o', 'Color', colors(i));
        hold on

        % Perform CCPP within the sector
        coverage_path = ccpp(nodes,start_positions);

        % Perform coverage analysis
        totalCoverageMatrix = get_coverage(gridx,gridy,numNodes,nodes,detectionRadius,totalCoverageMatrix);

        % Plot the coverage path for UAV
        plot(coverage_path(:,1), coverage_path(:,2), '-', 'Color', colors(i), 'LineWidth', 2);

    end

end

%% Coverage Calculations

% Remove values that are doubled up in coverage (> 1)
for i = 1:gridy % rows
    for j = 1:gridx % cols

        if totalCoverageMatrix(i,j) > 1
           
           totalCoverageMatrix(i,j) = 1;

        end

    end
end

% Calculate percentage coverage
coverage = 0; % Initialise coverage as zero

for i = 1:gridy % rows

    rowSum = sum(totalCoverageMatrix(i,:));

    coverage = coverage + rowSum;
end

percentageCoverage = coverage/(gridx*gridy)*100;
fprintf('Percentage coverage = %0.2f%% \n',percentageCoverage);

% plot visualised coverage map
% figure(2)
% h = heatmap(uint8(totalCoverageMatrix));

%% %%%%%%%%%%%%%%%%%%%%%%%%%% Functions %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Cooperative Coverage Path Planning Function
function path = ccpp(nodes,start_positions)
    % Simple CCPP: nearest neighbor algorithm starting from start_position
    numNodes = size(nodes, 1);
    visited = zeros(numNodes, 1);
    path = [];

    % Find which node is the closest to the starting point
    for i = 1:size(nodes,1)

        % Calculate distances between the node and chosen voronoi point
        distFromStart(i) = sqrt( (nodes(i,1)-start_positions(1,1))^2 + (nodes(i,2)-start_positions(1,2))^2 );

    end

    % If the indice of the minimum distance to a node is equal to the
    % uav number then it is in the correct sector
    [~,minDistFromStart] = min(distFromStart);
    current_position = nodes(minDistFromStart,:);
    
    while sum(visited) < numNodes
        % Find the nearest unvisited node
        dists = sqrt(sum((nodes(~visited, :) - current_position).^2, 2));
        [~, idx] = min(dists);
        nearest_node = find(~visited, idx);
        
        % Move to the nearest node
        current_position = nodes(nearest_node(end), :);
        path = [path; current_position];
        visited(nearest_node(end)) = true;
    end
    
    % Return to starting position at end of search manoeuvre
    % path = [path;start_position];
end

% Calculate coverage Function
function totalCoverageMatrix = get_coverage(gridx,gridy,numNodes,nodes,detectionRadius,totalCoverageMatrix)
coverageMatrix = zeros(gridy,gridx); % Coverage matrix for each UAV

    % Loop through each visitde node
    for j = 1:numNodes

        % loop through elements of coverage matrix
        for m = 1:gridy
            for n = 1:gridx

                % Calculate distance of each visited node to coverage matrix index
                % nodes
                dist = sqrt( ( nodes(j,1) - n )^2 + ( nodes(j,2) - (gridy-m) )^2  );

                % If index node is within detection radius then give
                % coverage matrix a value of 1
                if dist < detectionRadius

                    coverageMatrix(m,n) = 1;

                end
            end
        end

    end

    % Combine coverage matrices for multiple UAVs
    totalCoverageMatrix = totalCoverageMatrix + coverageMatrix;

end
