clear;
clc;
close all

% Define the size of the area
gridx = 500; % x length
gridy = 500; % y length
uavs = 1;    % Number of UAVs in simulation

% number of nodes per quadrant
numNodes = 200;

% Define detection radius
detectionRadius = 50; % (m)

% Divide the area into sectors depending on how many UAVs there are
if uavs == 1
    
    % Define the starting position of the UAV
    start_positions = [0, 0];
    sectors = [0, 0, gridx, gridy];
   
elseif uavs == 2
   
    start_positions = [0, 0; 
                       gridx,0];

    sectors = [0, 0, gridx/2, gridy;        % Left
               gridx/2, 0, gridx, gridy];   % Right
    
elseif uavs == 3

%     start_positions = [0, 0; 
%                        gridx,0;
%                        0, gridy];
    start_positions = [0, 0; 
                       0,0;
                       0, 0];

    sectors = [0, 0, gridx/2, gridy/2;       % Bottom left
               gridx/2, 0, gridx, gridy/2;   % Bottom right 
               0, gridy/2, gridx, gridy];    % Top half
    
else
    start_positions = [0, 0;                   % Bottom left
                       0, gridy;               % Top left
                       gridx, 0;               % Bottom right
                       gridx, gridy];          % Top right
    
    sectors = [0, 0, gridx/2, gridy/2;          % Bottom left
             0, gridy/2, gridx/2, gridy;        % Top left
             gridx/2, 0, gridx, gridy/2;        % Bottom right
             gridx/2, gridy/2, gridx, gridy];   % Top right
  
end

% Create PRM and CCPP for each UAV
figure(1);
hold on;
axis([0 gridx 0 gridy]);
title('Cooperative UAV Exploration');
colors = ['r', 'b', 'g', 'k'];
grid on
grid minor

% Initialise final coverage
totalCoverageMatrix = zeros(gridy,gridx); % Will be the total coverage of all UAVs

%% Main loop
for i = 1:uavs
    
    % Generate PRM for the current sector
    nodes = generate_nodes(sectors(i, :), numNodes);

    % Plot the PRM nodes
    plot(nodes(:,1), nodes(:,2), 'o', 'Color', colors(i));

    % Perform CCPP within the sector
    coverage_path = ccpp(nodes, start_positions(i, :));
 
    % Perform coverage analysis
    [coverageMatrix, totalCoverageMatrix] = get_coverage(gridx,gridy,numNodes,nodes,detectionRadius,totalCoverageMatrix);

    % Plot the coverage path
     plot(coverage_path(:,1), coverage_path(:,2), '-', 'Color', colors(i), 'LineWidth', 2);
end

%% Coverage Calculations

% Remove values that are doubled up in coverage (=2)
for i = 1:gridy % rows
    for j = 1:gridx % cols

        if totalCoverageMatrix(i,j) > 1
           
           totalCoverageMatrix(i,j) = 1;

        end

    end
end

% Calculate percentage coverage
coverage = 0; % Initialise coverage as zero
for i = 1:gridy % rows

    rowSum = sum(totalCoverageMatrix(i,:));

    coverage = coverage + rowSum;
end

percentageCoverage = coverage/(gridx*gridy)*100;
fprintf('Percentage coverage = %0.2f%% \n',percentageCoverage);

%%

% Legend on figure 1
if uavs == 1
    
elseif uavs == 2
    
    legend('UAV 1','', 'UAV 2','');
    
elseif uavs == 3
    
    legend('UAV 1','', 'UAV 2','', 'UAV 3','');
    
else
    legend('UAV 1','', 'UAV 2','', 'UAV 3','','UAV 4','');
    
end

% plot visualised coverage map
figure(2)
heatmap(uint8(totalCoverageMatrix))

%% --- Functions --- %%

% Function to generate probabilistic nodes
function nodes = generate_nodes(sector, numNodes)
    % Generate random nodes within the quadrant
    nodes = [rand(numNodes, 1) * (sector(3) - sector(1)) + sector(1), ...
             rand(numNodes, 1) * (sector(4) - sector(2)) + sector(2)];
end

function path = ccpp(nodes, start_position)
    % Simple CCPP: nearest neighbor algorithm starting from start_position
    numNodes = size(nodes, 1);
    visited = zeros(numNodes, 1);
    path = start_position;
    
    current_position = start_position;
    while sum(visited) < numNodes
        % Find the nearest unvisited node
        dists = sqrt(sum((nodes(~visited, :) - current_position).^2, 2));
        [~, idx] = min(dists);
        nearest_node = find(~visited, idx);
        
        % Move to the nearest node
        current_position = nodes(nearest_node(end), :);
        path = [path; current_position];
        visited(nearest_node(end)) = true;
    end
    
    % Return to starting position at end of search manoeuvre
    path = [path;start_position];
end

function [coverageMatrix, totalCoverageMatrix] = get_coverage(gridx,gridy,numNodes,nodes,detectionRadius,totalCoverageMatrix);
coverageMatrix = zeros(gridy,gridx); % Coverage matrix for each UAV

% Loop through each visitde node
for j = 1:numNodes

    % loop through elements of coverage matrix
    for m = 1:gridy
        for n = 1:gridx
            
            % Calculate distance of each visited node to coverage matrix index
            % nodes
            dist = sqrt( ( nodes(j,1) - n )^2 + ( nodes(j,2) - (gridy-m) )^2  );

            % If index node is within detection radius then give
            % coverage matrix a value of 1
            if dist < detectionRadius

                coverageMatrix(m,n) = 1;

            end
        end
    end

end

% Combine coverage matrices for multiple UAVs
totalCoverageMatrix = totalCoverageMatrix + coverageMatrix;

end
