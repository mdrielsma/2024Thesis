clear;
clc;
close all

% Define the size of the area
gridsize = 1000; % square with side length
num_uavs = 1;

% number of nodes per quadrant
numNodes = 200;
numEdges = 10;

% Divide the area into sectors depending on how many UAVs there are
if num_uavs == 1
    
    % Define the starting position of the UAV
    start_positions = [0, 0];
    sectors = [0, 0, gridsize, gridsize];
   
elseif num_uavs == 2
   
    start_positions = [0, 0; 
                    gridsize,0];

    sectors = [0, 0, gridsize/2, gridsize;          % Left
               gridsize/2, 0, gridsize, gridsize];   % Right
    
elseif num_uavs == 3

    start_positions = [0, 0; 
                       gridsize,0;
                       0, gridsize];

    sectors = [0, 0, gridsize/2, gridsize/2;          % Bottom left
               gridsize/2, 0, gridsize, gridsize/2;   % Bottom right 
               0, gridsize/2, gridsize, gridsize];  % Top
    
else
    start_positions = [0, 0;
                   0, gridsize; 
                   gridsize, 0; 
                   gridsize, gridsize];
    
    sectors = [0, 0, gridsize/2, gridsize/2;                % Bottom left
             0, gridsize/2, gridsize/2, gridsize;           % Top left
             gridsize/2, 0, gridsize, gridsize/2;           % Bottom right
             gridsize/2, gridsize/2, gridsize, gridsize];   % Top right
  
end

% Create PRM and CCPP for each UAV
figure;
hold on;
axis([0 gridsize 0 gridsize]);
title('Cooperative UAV Exploration');
colors = ['r', 'g', 'b', 'k'];
grid on
grid minor
axis square

for i = 1:num_uavs
    % Generate PRM for the current quadrant
    nodes = generate_nodes(sectors(i, :), numNodes);

    % Plot the PRM nodes
    plot(nodes(:,1), nodes(:,2), 'o', 'Color', colors(i));

    % Perform CCPP within the quadrant
    coverage_path = ccpp(nodes, start_positions(i, :));

    % Plot the coverage path
     plot(coverage_path(:,1), coverage_path(:,2), '-', 'Color', colors(i), 'LineWidth', 2);
end

hold off;

% Function to generate probabilistic nodes
function nodes = generate_nodes(quadrant, numNodes)
    % Generate random nodes within the quadrant
    nodes = [rand(numNodes, 1) * (quadrant(3) - quadrant(1)) + quadrant(1), ...
             rand(numNodes, 1) * (quadrant(4) - quadrant(2)) + quadrant(2)];
end

function path = ccpp(nodes, start_position)
    % Simple CCPP: nearest neighbor algorithm starting from start_position
    numNodes = size(nodes, 1);
    visited = zeros(numNodes, 1);
    path = start_position;
    
    current_position = start_position;
    while sum(visited) < numNodes
        % Find the nearest unvisited node
        dists = sqrt(sum((nodes(~visited, :) - current_position).^2, 2));
        [~, idx] = min(dists);
        nearest_node = find(~visited, idx);
        
        % Move to the nearest node
        current_position = nodes(nearest_node(end), :);
        path = [path; current_position];
        visited(nearest_node(end)) = true;
    end
end
