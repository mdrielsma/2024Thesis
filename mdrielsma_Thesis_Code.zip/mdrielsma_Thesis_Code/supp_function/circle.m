
function [x,y] = circle(xc,yc,r,startAngle)

%% Generate circle

% Centre
% xc = 500;
% yc = 500;
% 
% % Radius
% r = 100;

% Angles
theta = linspace(startAngle,2*pi+startAngle,200);
x = zeros(length(theta));
y = zeros(length(theta));

% Generate circle
for i = 1:length(theta)

    x(i) = r*cos(theta(i)) + xc;
    y(i) = r*sin(theta(i)) + yc;

end

% plot(xc,yc,'ro','linewidth',2);
% hold on
% plot(x,y,'b','linewidth',2);
% axis square
% grid on

end
