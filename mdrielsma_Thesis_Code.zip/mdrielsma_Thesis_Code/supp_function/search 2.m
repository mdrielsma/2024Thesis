% Function that performs search mode

function [coverage_path] = search(gridx,gridy,uavs,numNodes,offset)

%%%%%%%%%%%%%%%%%%%% INPUT VARIABLES %%%%%%%%%%%%%%%%%%%%

% gridx = 1000;        % x length of grid space
% gridy = 1000;        % y length of grid space
% uavs = 1;            % Number of UAVs
% numNodes = 100;      % Number of nodes per quadrant

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% UAVs:
% UAVs all start in bottom left corner
% start_positions = [gridx/2, gridy/2];
start_positions = [0, 0];

% Define detection radius
detectionRadius = 50; % (m)

% Initialise final coverage
totalCoverageMatrix = zeros(gridy,gridx); % Will be the total coverage of all UAVs

%% --- Voronoi and PRM generation --- %%

% Centre of grid space
centre = [gridx/2, gridy/2];

% Radius of voronoi points circle
r = gridy/4;

% Initialise x and y coords of voronoi points
voronoi_x = zeros(1,uavs);
voronoi_y = zeros(1,uavs);

for i = 1:uavs
    
    % Angular separation
    theta = 2*pi/uavs;
    
    % Calculate voronoi x and y coordinates
    voronoi_x(i) = gridx/2 + r*cos((i-1)*theta);
    voronoi_y(i) = gridy/2 + r*sin((i-1)*theta);
    
end

colors = ['r', 'b', 'g', 'k','m','c'];

%% 

% Distances from node to voronoi points
voronoi_dist = zeros(1,uavs);

for i = 1:uavs
    
    % Initialise nodes list and node counter
    nodes = [];
    nodeCounter = 1;

    while nodeCounter <= numNodes

        % Generate a random node
        node = [rand(1,1)*gridx, rand(1,1)*gridy];

        % Loop through different voronoi points
        for j = 1:length(voronoi_x)

            % Calculate distances between the node and chosen voronoi point
            voronoi_dist(j) = sqrt( (node(1)-voronoi_x(j))^2 + (node(2)-voronoi_y(j))^2 );

        end
        
        % If the indice of the minimum distance to a node is equal to the
        % uav number then it is in the correct sector
        [~,minDist] = min(voronoi_dist);
        if minDist == i

           % Add node to nodes list
           nodes = [nodes;node];
                   
            % Increment node counter
            nodeCounter = nodeCounter + 1;

        end

    end

    % Plot the PRM nodes
%     plot(nodes(:,1), nodes(:,2), 'o', 'Color', colors(i));
    
    % Perform CCPP within the sector
    coverage_path = ccpp(nodes, start_positions);
    
    % Perform coverage analysis
    [coverageMatrix, totalCoverageMatrix] = get_coverage(gridx,gridy,numNodes,nodes,detectionRadius,totalCoverageMatrix);

    % Plot the coverage path
     plot(coverage_path(:,1), coverage_path(:,2), '-', 'Color', colors(i), 'LineWidth', 2);
    
end

%% Coverage Calculations

% Remove values that are doubled up in coverage (> 1)
for i = 1:gridy % rows
    for j = 1:gridx % cols

        if totalCoverageMatrix(i,j) > 1
           
           totalCoverageMatrix(i,j) = 1;

        end

    end
end

% Calculate percentage coverage
coverage = 0; % Initialise coverage as zero

for i = 1:gridy % rows

    rowSum = sum(totalCoverageMatrix(i,:));

    coverage = coverage + rowSum;
end

percentageCoverage = coverage/(gridx*gridy)*100;
fprintf('Percentage coverage = %0.2f%% \n',percentageCoverage);

% plot visualised coverage map
% figure(2)
% h = heatmap(uint8(totalCoverageMatrix));


%% --- Functions --- %%

% Cooperative Coverage Path Planning Function
function path = ccpp(nodes, start_position)
    % Simple CCPP: nearest neighbor algorithm starting from start_position
    numNodes = size(nodes, 1);
    visited = zeros(numNodes, 1);
    path = start_position;
    
    current_position = start_position;
    while sum(visited) < numNodes
        % Find the nearest unvisited node
        dists = sqrt(sum((nodes(~visited, :) - current_position).^2, 2));
        [~, idx] = min(dists);
        nearest_node = find(~visited, idx);
        
        % Move to the nearest node
        current_position = nodes(nearest_node(end), :);
        path = [path; current_position];
        visited(nearest_node(end)) = true;
    end
    
    % Return to starting position at end of search manoeuvre
    % path = [path;start_position];
end

% Calculate coverage Function
function [coverageMatrix, totalCoverageMatrix] = get_coverage(gridx,gridy,numNodes,nodes,detectionRadius,totalCoverageMatrix);
coverageMatrix = zeros(gridy,gridx); % Coverage matrix for each UAV

    % Loop through each visitde node
    for j = 1:numNodes

        % loop through elements of coverage matrix
        for m = 1:gridy
            for n = 1:gridx

                % Calculate distance of each visited node to coverage matrix index
                % nodes
                dist = sqrt( ( nodes(j,1) - n )^2 + ( nodes(j,2) - (gridy-m) )^2  );

                % If index node is within detection radius then give
                % coverage matrix a value of 1
                if dist < detectionRadius

                    coverageMatrix(m,n) = 1;

                end
            end
        end

    end

    % Combine coverage matrices for multiple UAVs
    totalCoverageMatrix = totalCoverageMatrix + coverageMatrix;

end



end