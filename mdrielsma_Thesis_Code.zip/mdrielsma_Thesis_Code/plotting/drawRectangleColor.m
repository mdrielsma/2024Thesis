function [handle] = drawRectangleColor(centre, edge_length_x, edge_length_y,offset)

x                   = centre(1);
y                   = centre(2);

x_bottom_l          = x-edge_length_x/2;
y_bottom_l          = y-edge_length_y/2;

x_bottom_r          = x+edge_length_x/2;
y_bottom_r          = y-edge_length_y/2;

x_top_r             = x+edge_length_x/2;
y_top_r             = y+edge_length_y/2;

x_top_l             = x-edge_length_x/2;
y_top_l             = y+edge_length_y/2;

offset = 200;

hold on;
plot3([x_bottom_l+offset,x_bottom_r-offset],[y_bottom_l+offset,y_bottom_r+offset],[2,2],'k-','linewidth',4); % Bottom
plot3([x_bottom_r-offset,x_top_r-offset],[y_bottom_r+offset,y_top_r-offset],[2,2],'k-','linewidth',4); % Right
plot3([x_top_r-offset,x_top_l+offset],[y_top_r-offset,y_top_l-offset],[2,2],'k-','linewidth',4); % Top
handle = plot3([x_top_l+offset,x_bottom_l+offset],[y_top_l-offset,y_bottom_l+offset],[2,2],'k-','linewidth',4); % Left